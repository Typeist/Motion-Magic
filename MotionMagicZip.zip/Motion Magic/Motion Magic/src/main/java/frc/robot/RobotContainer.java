// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot;

import edu.wpi.first.wpilibj.GenericHID;
import edu.wpi.first.wpilibj.XboxController;
import edu.wpi.first.wpilibj.buttons.Button;
import edu.wpi.first.wpilibj.buttons.JoystickButton;
import frc.robot.commands.ManualControlIntake;
import frc.robot.subsystems.Intake;
import edu.wpi.first.wpilibj2.command.Command;

/**
 * This class is where the bulk of the robot should be declared. Since Command-based is a
 * "declarative" paradigm, very little robot logic should actually be handled in the {@link Robot}
 * periodic methods (other than the scheduler calls). Instead, the structure of the robot (including
 * subsystems, commands, and button mappings) should be declared here.
 */
public class RobotContainer {

  private final Intake m_Intake = new Intake();
  private final ManualControlIntake m_CTRLIntake = new ManualControlIntake();

    //ctrl config, bindings
  public static XboxController controller_1 = new XboxController(0);

  public static Button xbox_1_a = new JoystickButton(controller_1, 1);
  public static Button xbox_1_lb = new JoystickButton(controller_1, 5);
  public static Button xbox_1_lstick = new JoystickButton(controller_1, 9);
  public static Button xbox_1_rstick = new JoystickButton(controller_1, 10);
 /* public static Button xbox_2_a = new JoystickButton(controller_2, 1);
  public static Button xbox_2_b = new JoystickButton(controller_2, 2);
  public static Button xbox_2_x = new JoystickButton(controller_2, 3);
  public static Button xbox_2_select = new JoystickButton(controller_2, 7);
  public static Button xbox_2_y = new JoystickButton(controller_2, 4); **/
  
  public RobotContainer() {
 
    configureButtonBindings();
    configureSubsystems();
  }

  private void configureSubsystems() {
    m_Intake.Sys_Init();
  }

  private void configureButtonBindings() {
  }

  /**
   * Use this to pass the autonomous command to the main {@link Robot} class.
   *
   * @return the command to run in autonomous
   */
  //public Command getAutonomousCommand() {
    // An ExampleCommand will run in autonomous
    //return m_autoCommand;
  }
//}
