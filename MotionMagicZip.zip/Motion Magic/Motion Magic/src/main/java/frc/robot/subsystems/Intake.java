package frc.robot.subsystems;

import edu.wpi.first.wpilibj.TimedRobot;
import frc.robot.Constants;
import frc.robot.commands.ManualControlIntake;
import edu.wpi.first.wpilibj.Joystick;

import com.ctre.phoenix.motorcontrol.can.TalonFX;
import com.ctre.phoenix.motorcontrol.TalonFXControlMode;
import com.ctre.phoenix.motorcontrol.TalonFXFeedbackDevice;
import com.ctre.phoenix.motorcontrol.ControlMode;
import com.ctre.phoenix.motorcontrol.StatusFrameEnhanced;
import com.ctre.phoenix.motorcontrol.SupplyCurrentLimitConfiguration;

public class Intake extends TimedRobot {
	/* Hardware */
	TalonFX m_ArmShooter = new TalonFX(4); //insert CAN ID for shooter arm motor

	/* Used to build string throughout loop */
	StringBuilder _sb = new StringBuilder();

	/** How much smoothing [0,8] to use during MotionMagic */
	int _smoothing = 0;

	/** save the last Point Of View / D-pad value */
	int _pov = -1;

	public void Sys_Init() {
		/* Factory default hardware to prevent unexpected behavior */
    m_ArmShooter.configFactoryDefault();
    m_ArmShooter.configSupplyCurrentLimit(new SupplyCurrentLimitConfiguration(true, 40, 0, 0));

		/* Configure Sensor Source for Pirmary PID */
		m_ArmShooter.configSelectedFeedbackSensor(TalonFXFeedbackDevice.IntegratedSensor, Constants.kPIDLoopIdx,
				Constants.kTimeoutMs);

		/* set deadband to super small 0.001 (0.1 %).
			The default deadband is 0.04 (4 %) */
		m_ArmShooter.configNeutralDeadband(0.001, Constants.kTimeoutMs);

		/**
		 * Configure Talon FX Output and Sesnor direction accordingly Invert Motor to
		 * have green LEDs when driving Talon Forward / Requesting Postiive Output Phase
		 * sensor to have positive increment when driving Talon Forward (Green LED)
		 */
		m_ArmShooter.setSensorPhase(false);
		m_ArmShooter.setInverted(false);
		/*
		 * Talon FX does not need sensor phase set for its integrated sensor
		 * This is because it will always be correct if the selected feedback device is integrated sensor (default value)
		 * and the user calls getSelectedSensor* to get the sensor's position/velocity.
		 * 
		 * https://phoenix-documentation.readthedocs.io/en/latest/ch14_MCSensor.html#sensor-phase
		 */
        // m_ArmShooter.setSensorPhase(true);

		/* Set relevant frame periods to be at least as fast as periodic rate */
		m_ArmShooter.setStatusFramePeriod(StatusFrameEnhanced.Status_13_Base_PIDF0, 10, Constants.kTimeoutMs);
		m_ArmShooter.setStatusFramePeriod(StatusFrameEnhanced.Status_10_MotionMagic, 10, Constants.kTimeoutMs);

		/* Set the peak and nominal outputs */
		m_ArmShooter.configNominalOutputForward(0, Constants.kTimeoutMs);
		m_ArmShooter.configNominalOutputReverse(0, Constants.kTimeoutMs);
		m_ArmShooter.configPeakOutputForward(1, Constants.kTimeoutMs);
		m_ArmShooter.configPeakOutputReverse(-1, Constants.kTimeoutMs);

		/* Set Motion Magic gains in slot0 - see documentation */
		m_ArmShooter.selectProfileSlot(Constants.kSlotIdx, Constants.kPIDLoopIdx);
		m_ArmShooter.config_kF(Constants.kSlotIdx, Constants.shooterArmPID.kF, Constants.kTimeoutMs);
		m_ArmShooter.config_kP(Constants.kSlotIdx, Constants.shooterArmPID.kP, Constants.kTimeoutMs);
		m_ArmShooter.config_kI(Constants.kSlotIdx, Constants.shooterArmPID.kI, Constants.kTimeoutMs);
		m_ArmShooter.config_kD(Constants.kSlotIdx, Constants.shooterArmPID.kD, Constants.kTimeoutMs);

		/* Set acceleration and vcruise velocity - see documentation */
		m_ArmShooter.configMotionCruiseVelocity(600, Constants.kTimeoutMs);
		m_ArmShooter.configMotionAcceleration(600, Constants.kTimeoutMs);

		/* Zero the sensor once on robot boot up */
		m_ArmShooter.setSelectedSensorPosition(0, Constants.kPIDLoopIdx, Constants.kTimeoutMs);
  }
  public void teleopPeriodic() {
	m_ArmShooter.set(ControlMode.MotionMagic, Constants.shooter_ForwardShot);
  }

  
	public static void manualShooter(double rawAxis) {
		
	}
}

