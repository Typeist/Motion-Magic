package frc.robot.commands.shooter;

import edu.wpi.first.wpilibj.command.Command;
import frc.robot.RobotContainer;
import frc.robot.Robot;
import frc.robot.Intake;

public class ManualControlIntake extends Command {

  Private Final Intake m_Intake;

  public ManualControlIntake(Intake Subsystem) {
    m_Intake = subsystem;

    // Use requires() here to declare subsystem dependencies
    requires();
  }

  // Called just before this Command runs the first time
  @Override
  protected void initialize() {
    //Robot._robotTime.timePrintln("[SHOOTER] Warning - Shooter has enabled manual override - We are really screwed now.");
    Robot._Shooter.enableVoltageCompensation(true);
  }

  // Called repeatedly when this Command is scheduled to run
  @Override
  protected void execute() {
    Robot._Shooter.manualShooter(-OI.xbox2.getRawAxis(5));
  }

  // Make this return true when this Command no longer needs to run execute()
  @Override
  protected boolean isFinished() {
    return false;
  }

  // Called once after isFinished returns true
  @Override
  protected void end() {
    Robot._Shooter.enableVoltageCompensation(false);
  }

  // Called when another command which requires one or more of the same
  // subsystems is scheduled to run
  @Override
  protected void interrupted() {
    end();
  }
}

